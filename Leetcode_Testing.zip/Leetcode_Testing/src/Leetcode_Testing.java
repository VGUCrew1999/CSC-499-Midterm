/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kenkf
 */
 
 import java.util.Scanner;
public class Leetcode_Testing {
    
    
    static int reverse(int x){                                                      // reverses 32 bit integers that don't cause overflow
        
        int rev = 0;
        
        while (x != 0){
            int pop = x % 10;                                                       // works like the pop function when using a stack
            x /= 10;
            if (rev > Integer.MAX_VALUE/10 || (rev == Integer.MAX_VALUE/10 && pop > 7))     // will it cause overflow
                return 0;
            if (rev < Integer.MIN_VALUE/10 || (rev == Integer.MIN_VALUE/10 && pop < -8))    // will it cause overflow
                return 0;
            
            rev = rev * 10 + pop;
        }
        
        return rev;
        
    }
    
    static String reverseAny(String x){                                             // can reverse integers that cause overflow when flipped
        String rev = "";
        for (int i = 0; i < x.length(); i++) {
            rev = x.charAt(i) + rev;
        }
        
        if(rev.charAt(0) == '0'){                                                   // make sure it doesn't begin with a 0
            String rev2 = "";
            for (int i = 1; i < rev.length(); i++) {
                rev2 = rev2 + rev.charAt(i);
            }
            rev = rev2;
        }
        
        if(rev.charAt(rev.length()-1) == '-'){
            String rev2 = rev.substring(0, rev.length()-1);
            rev = '-' + rev2;
        }
        
        return rev;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        //int x = 1534236469;
        // 123
        // 120
        
        int selection = 0;
        String stringInput = "";
        int intInput = 0;
        
        do {
            System.out.println("Menu:");
            System.out.println("1. Reverse Integer");
            System.out.println("2. Reverse Any Integer");
            System.out.println("-1. Exit");
            System.out.println("Please enter a number: ");
            selection = in.nextInt();
            System.out.println();
            
            switch(selection){
                case 1: {
                    System.out.println("Enter an integer:");
                    intInput = in.nextInt();
                    System.out.println("Input: " + intInput);
                    System.out.println("Output: " + reverse(intInput));
                    System.out.println();
                    System.out.println();
                    break;
                }
                
                case 2: {
                    System.out.println("Enter an integer:");
                    intInput = in.nextInt();
                    stringInput = Integer.toString(intInput);                   // fixes issue with in.nextLine
                    System.out.println("Input: " + stringInput);
                    System.out.println("Output: " + reverseAny(stringInput));
                    System.out.println();
                    System.out.println();
                    break;
                }
                case -1:
                    System.out.println("Exiting Program");
                    System.out.println();
                    System.out.println();
                    break;
                default:
                    System.out.println("Please try again.");
                    System.out.println();
                    System.out.println();
                    break;
            }
            
            
        } while (selection >= 0);
        
    }
    
}
