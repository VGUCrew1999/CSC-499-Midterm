/*
course: CSC190
project: P0824a
date: 08/24/17
author: Kenneth Fugate
purpose: This program shows how to use arithmetic operators
+, -, *, /, %
*/

public class P0824a {
    public static void main(String[] args) {
       System.out.println(7+2);
       System.out.println(7-2);
       System.out.println(7*2);
       System.out.println(7/2); //integer div
       System.out.println(7%2); //remainder
       System.out.println(7.0/2); //3.5
       System.out.println(7/2.0); //3.5
       System.out.println(7.0/2.0); //3.5
       
       System.out.println(7/2*-3); //-9
       System.out.println(8/2*4); //16
       
       //more on /(div) and %(mod)
       System.out.println(7/2); //3
       System.out.println(-7/2); //-3
       System.out.println(7/-2); //-3
       System.out.println(-7/-2); //3
       System.out.println(7%2); //1
       System.out.println(-7%2); //-1
       System.out.println(7%-2); //1
       System.out.println(-7%-2); //-1
       
       //built-in methods
       System.out.println(Math.sqrt(5));
       System.out.println(Math.sqrt(4)); //2.0
       System.out.println(Math.sqrt(-4)); //invalid - NaN
       
       System.out.println(Math.pow(5,3)); //125.0
       System.out.println(Math.pow(5,-3)); //1/125 = 0.008
       System.out.println(Math.pow(-5,3)); //-125
       System.out.println(Math.pow(-5,-3)); //1/-125 = -0.008
       
       System.out.println(Math.ceil(1.4)); //2.0 //round up
       System.out.println(Math.ceil(1.5)); //2.0
       System.out.println(Math.ceil(1.6)); //2.0
       System.out.println(Math.ceil(1.0)); //2.0
       System.out.println(Math.floor(1.4)); //1.0 //round down
       System.out.println(Math.floor(1.5)); //1.0
       System.out.println(Math.floor(1.6)); //1.0
       System.out.println(Math.floor(1.0)); //1.0
       System.out.println(Math.round(1.4)); //1
       System.out.println(Math.round(1.5)); //2
       System.out.println(Math.round(1.6)); //2
       System.out.println(Math.round(1.0)); //2
       
       System.out.println(Math.ceil(-1.4)); //-1.0 //round up
       System.out.println(Math.ceil(-1.5)); //-1.0
       System.out.println(Math.ceil(-1.6)); //-1.0
       System.out.println(Math.ceil(-1.0)); //-1.0
       System.out.println(Math.floor(-1.4)); //-2.0 //round down
       System.out.println(Math.floor(-1.5)); //-2.0
       System.out.println(Math.floor(-1.6)); //-2.0
       System.out.println(Math.floor(-1.0)); //-2.0
       System.out.println(Math.round(-1.4)); //-1
       System.out.println(Math.round(-1.5)); //-2
       System.out.println(Math.round(-1.6)); //-2
       System.out.println(Math.round(-1.0)); //-1
       
       
       System.out.println(Math.max(1,2)); //2
       System.out.println(Math.min(1,2)); //1
       //how to find the smallest of 3, -1, 0
       System.out.println(Math.min(Math.min(3, -1),0)); //-1
    }    
}
