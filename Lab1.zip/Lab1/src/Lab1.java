
/*
course: CSC190
project: Lab1
date: 8/25/17
author: Kenneth Fugate
purpose: Assuming there are 5 coin types available: dollars(100 cents), 
quarters(25 cents), dimes(10 cents), nickels(5 cents) and pennies(1 cent),
this program reads a monetary amount in cents and prints
the smallest possible number of coints equaling the amount.
For instance, if 289 is read, your program will print 10 coins: 2 dollars, 
3 quarters, 1 dime, 0 nickels and 4 pennies.
 */
import java.util.Scanner;
public class Lab1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int cents;
        int dollars, quarters, dimes, nickels, pennies; //output variables
        
        System.out.print("Enter a number(such as 289):");
        cents = in.nextInt(); //step for reading an integer
        
        dollars = cents/100; //steps for creating variables
        cents = cents%100;
        quarters = cents/25;
        cents = cents%25;
        dimes = cents/10;
        cents = cents%10;
        nickels = cents/5;
        cents = cents%5;
        pennies = cents/1;
        
        System.out.println("number of coins = "+ (dollars+quarters+dimes+nickels+pennies)); //steps for printing results
        System.out.println("number of dollars = "+ dollars);
        System.out.println("number of quarters = "+ quarters);
        System.out.println("number of dimes = "+ dimes);
        System.out.println("number of nickels = "+ nickels);
        System.out.println("number of pennies = "+ pennies);
    }
    
}
